package com.example.fscalculator;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button startButton;
    private SeekBar speedSlider;
    private TextView statusText;
    public static int clickSpeed = 100;
    private boolean isServiceRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startButton = findViewById(R.id.btnStart);
        speedSlider = findViewById(R.id.speedSlider);
        statusText = findViewById(R.id.statusText);

        speedSlider.setProgress(clickSpeed);
        speedSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                clickSpeed = progress;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        startButton.setOnClickListener(v -> {
            if (!isServiceRunning) {
                startService(new Intent(this, AutoMathService.class));
                isServiceRunning = true;
                statusText.setText("الحالة: نشط");
                startButton.setText("إيقاف الخدمة");
            } else {
                stopService(new Intent(this, AutoMathService.class));
                isServiceRunning = false;
                statusText.setText("الحالة: متوقف");
                startButton.setText("تشغيل الخدمة");
            }
        });
    }
}